function FisherFaces(T)
%T is the Nxd training data for N=100 images (2 per person). d is the dimension of the features, representing an image.
%Implement the code (see instruction in the pdf file)
%F is the low-dimensional basis and mn if the mean of the training set.
 
 save FisherSpace.mat F mn;
 